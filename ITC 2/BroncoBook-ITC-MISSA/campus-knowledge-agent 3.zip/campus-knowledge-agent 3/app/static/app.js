let conversationId = null;

const messagesEl = document.getElementById("messages");
const formEl = document.getElementById("chatForm");
const inputEl = document.getElementById("messageInput");
const starterEl = document.getElementById("starterQuestions");
const template = document.getElementById("messageTemplate");

function addMessage(role, body, sources = []) {
  const node = template.content.cloneNode(true);
  node.querySelector(".message-role").textContent = role;
  node.querySelector(".message-body").textContent = body;

  const sourcesEl = node.querySelector(".sources");
  if (sources.length) {
    const title = document.createElement("div");
    title.className = "sources-title";
    title.textContent = "Sources";
    sourcesEl.appendChild(title);

    sources.forEach((source) => {
      const card = document.createElement("a");
      card.className = "source-card";
      card.href = source.source_url;
      card.target = "_blank";
      card.rel = "noreferrer";
      card.innerHTML = `
        <strong>${escapeHtml(source.title)}</strong>
        <span>${escapeHtml(source.section || source.markdown_file)}</span>
        <p>${escapeHtml(source.snippet)}</p>
      `;
      sourcesEl.appendChild(card);
    });
  }

  messagesEl.appendChild(node);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function loadStarters() {
  const response = await fetch("/api/starter-questions");
  const data = await response.json();
  starterEl.innerHTML = "";
  data.questions.forEach((question) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "chip";
    button.textContent = question;
    button.addEventListener("click", () => {
      inputEl.value = question;
      inputEl.focus();
    });
    starterEl.appendChild(button);
  });
}

async function loadAnalytics() {
  const response = await fetch("/api/analytics");
  const data = await response.json();
  document.getElementById("metricQueries").textContent = data.total_queries;
  document.getElementById("metricUnanswered").textContent = data.unanswered_queries;
  document.getElementById("metricTools").textContent = data.tool_calls;
  document.getElementById("metricSources").textContent = data.avg_sources_per_answer;
}

formEl.addEventListener("submit", async (event) => {
  event.preventDefault();
  const message = inputEl.value.trim();
  if (!message) return;

  addMessage("You", message);
  inputEl.value = "";
  addMessage("Assistant", "Thinking...");
  const thinkingCard = messagesEl.lastElementChild;

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, conversation_id: conversationId }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.detail || "Request failed.");
    }
    conversationId = data.conversation_id;
    thinkingCard.querySelector(".message-body").textContent = data.answer;
    const sourcesContainer = thinkingCard.querySelector(".sources");
    sourcesContainer.innerHTML = "";
    if (data.sources?.length) {
      const title = document.createElement("div");
      title.className = "sources-title";
      title.textContent = "Sources";
      sourcesContainer.appendChild(title);
      data.sources.forEach((source) => {
        const card = document.createElement("a");
        card.className = "source-card";
        card.href = source.source_url;
        card.target = "_blank";
        card.rel = "noreferrer";
        card.innerHTML = `
          <strong>${escapeHtml(source.title)}</strong>
          <span>${escapeHtml(source.section || source.markdown_file)}</span>
          <p>${escapeHtml(source.snippet)}</p>
        `;
        sourcesContainer.appendChild(card);
      });
    }
    await loadAnalytics();
  } catch (error) {
    thinkingCard.querySelector(".message-body").textContent = `Error: ${error.message}`;
  }
});

loadStarters();
loadAnalytics();
